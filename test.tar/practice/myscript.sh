#!/usr/bin/bash
ls -l
pwd
cat -n HelloWorld.java
df -lh

